const express = require('express')
const { buscarClientes } = require('./src/DAO/cliente/buscarClientes.js')
const app = express()
const  {conexao , closeConexao , testarConexao}= require('./src/DAO/conexao.js')
const { buscarProduto } = require('./src/DAO/produto/produto.js')
const { buscarPedidos } = require('./src/DAO/pedidos/pedidos.js')
app.get('/enpresalimpesa/v1', (req, res) => {
    let respInicial = {
        msg: "Aplicação Funcionando"
    }
    res.json(respInicial)
})

app.get('/app/v1/cliente', async (req, res) =>{
    let clientes = await buscarClientes()
    res.json(clientes)
})

app.get('/app/v1/produto', async (req, res) =>{
    let produto = await buscarProduto()
    res.json (produto)
})
app.get('/app/v1/pedidos', async (req, res) =>{
    let pedidos = await buscarPedidos()
    res.json (pedidos)
})


const porta = 3000

app.listen(porta, () =>{
    console.log("Operando na porta " + porta),
    testarConexao()
})